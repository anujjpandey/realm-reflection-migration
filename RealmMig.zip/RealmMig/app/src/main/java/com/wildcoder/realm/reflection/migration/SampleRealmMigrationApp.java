package com.wildcoder.realm.reflection.migration;

import android.app.Application;

import com.wildcoder.realm.reflection.migration.utilities.RealmAutoMigrations;

import io.realm.BuildConfig;
import io.realm.Realm;
import io.realm.RealmConfiguration;

/**
 * Created by apandey1 on 28/10/2022 AD.
 * KentCam
 * apandey1@kent.co.in
 */
public class SampleRealmMigrationApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        this.onCreateRealm();
    }

    private void onCreateRealm() {
        Realm.init(this);
        RealmConfiguration configuration = new RealmConfiguration.Builder().name("mydb.realm").schemaVersion(BuildConfig.VERSION_CODE).migration(new RealmAutoMigrations()).build();
        Realm.setDefaultConfiguration(configuration);
        Realm.getInstance(configuration);
    }


    @Override
    public void onTerminate() {
        Realm.getDefaultInstance().close();
        super.onTerminate();
    }
}
