package com.wildcoder.realm.reflection.migration.utilities;

import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Set;

import io.realm.DynamicRealm;
import io.realm.RealmMigration;
import io.realm.RealmObjectSchema;
import io.realm.RealmSchema;

/**
 * Created by apandey1 on 28/10/2022 AD.
 * KentCam
 * apandey1@kent.co.in
 */
public class RealmAutoMigrations implements RealmMigration {

    private Class[] _models;

    public RealmAutoMigrations() {
        try {
            _models = getClasses("com.wildcoder.realm.reflection.migration.entities.db");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void migrate(DynamicRealm realm, long oldVersion, long newVersion) {
        final RealmSchema schema = realm.getSchema();

        for (Class classModel : _models) {
            final RealmObjectSchema userSchema = schema.get(classModel.getSimpleName());
            Field[] fields = classModel.getDeclaredFields();
            Set<String> fieldsDatabase = userSchema.getFieldNames();
            for (String fieldDatabase : fieldsDatabase) {
                Boolean removed = true;
                for (Field field : fields) {
                    if (field.getName().compareToIgnoreCase(fieldDatabase) == 0) {
                        removed = false;
                        Log.w("REMOVED", field.getName() + "removed from " + classModel.getName());
                        break;
                    }
                }
                if (removed) {
                    Log.w("REMOVING_AND_UPDATE", "schema of " + classModel.getName());
                    userSchema.removeField(fieldDatabase);
                }
            }
            for (Field field : fields) {
                Class type = field.getType();
                String name = field.getName();
                if (!userSchema.hasField(name)) {
                    userSchema.addField(name, findClassType(type));
                }
            }
        }
    }

    /**
     * @param cls Class cls add other primitive data types as per requirement
     * @return Class
     * <p>
     * On the beginning of the project make sure to add all the class type which
     * are different from it's primitive type
     *
     * </p>
     */
    private Class findClassType(Class cls) {
        String name = cls.getSimpleName();
        if (name.compareToIgnoreCase("string") == 0) {
            return String.class;
        } else if (name.compareToIgnoreCase("boolean") == 0) {
            return Boolean.class;
        } else if (name.compareToIgnoreCase("int") == 0) {
            return int.class;
        } else if (name.compareToIgnoreCase("float") == 0) {
            return float.class;
        } else if (name.compareToIgnoreCase("short") == 0) {
            return short.class;
        } else if (name.compareToIgnoreCase("double") == 0) {
            return double.class;
        } else if (name.compareToIgnoreCase("long") == 0) {
            return long.class;
        } else if (name.compareToIgnoreCase("boolean") == 0) {
            return Boolean.class;
        } else if (name.compareToIgnoreCase("byte") == 0) {
            return byte.class;
        } else if (name.compareToIgnoreCase("byte[]") == 0) {
            return byte[].class;
        }
        return cls;
    }

    public Class[] getClasses(String pckgname)
            throws ClassNotFoundException {
        ArrayList classes = new ArrayList();
        // Get a File object for the package
        File directory = null;/*from  ww w . j a v  a 2  s .  c  om*/
        try {
            directory = new File(Thread.currentThread()
                    .getContextClassLoader()
                    .getResource('/' + pckgname.replace('.', '/'))
                    .getFile());
        } catch (NullPointerException x) {
            throw new ClassNotFoundException(pckgname
                    + " does not appear to be a valid package");
        }
        if (directory.exists()) {
            // Get the list of the files contained in the package
            String[] files = directory.list();
            for (int i = 0; i < files.length; i++) {
                // we are only interested in .class files
                if (files[i].endsWith(".class")) {
                    // removes the .class extension
                    classes.add(Class.forName(pckgname + '.'
                            + files[i].substring(0, files[i].length() - 6)));
                }
            }
        } else {
            throw new ClassNotFoundException(pckgname
                    + " does not appear to be a valid package");
        }
        Class[] classesA = new Class[classes.size()];
        classes.toArray(classesA);
        return classesA;
    }
}
