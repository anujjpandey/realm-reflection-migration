package com.wildcoder.realm.reflection.migration.entities.db;

import io.realm.RealmObject;

/**
 * Created by apandey1 on 28/10/2022 AD.
 * KentCam
 * apandey1@kent.co.in
 */
public class TestObject extends RealmObject {
}
