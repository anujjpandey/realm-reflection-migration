# Found people are facing too much issues with Realm migrations.
* Adding a concept which can help to make it auto.